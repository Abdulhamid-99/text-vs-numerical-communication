"""Verify compact supplement integrity and aggregate statistical consistency.
Uses Python's standard library. Does not reproduce neural outputs or raw evidence.
"""
import csv, hashlib, json, math
from pathlib import Path

def verify(root):
    root = Path(root)
    manifest = json.loads((root/'manifest.json').read_text(encoding='utf-8'))
    expected = set(manifest['files']) | {'manifest.json'}
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    assert actual == expected, 'Package file inventory differs'
    for rel, record in manifest['files'].items():
        data = (root/rel).read_bytes()
        assert len(data) == record['bytes'], rel
        assert hashlib.sha256(data).hexdigest() == record['sha256'], rel
    def read(name):
        with (root/name).open(encoding='utf-8', newline='') as f:
            return list(csv.DictReader(f))
    actual_rows = read('actual_conditions.csv')
    policy = read('budget_loss_policies.csv')
    contrasts = read('primary_contrasts.csv')
    negatives = read('negative_controls.csv')
    controls = read('paired_world_controls.csv')
    assert [len(x) for x in [actual_rows,policy,contrasts,negatives,controls]] == [48,72,16,12,12]
    assert all(int(r['n_families']) == 64 for r in actual_rows+policy+contrasts+negatives+controls)
    counts = json.loads((root/'counts.json').read_text(encoding='utf-8'))
    assert counts['a_generations'] == 512 and counts['b_generations'] == 3072
    assert counts['encoder_forwards'] == 768 and counts['source_contract_failures'] == 0
    assert counts['additional_generations_from_all_replays'] == 0
    close = lambda a,b: math.isclose(float(a),float(b),rel_tol=1e-11,abs_tol=1e-17)
    actual_index = {(r['model'],r['task'],r['condition']):r for r in actual_rows}
    policy_index = {(r['model'],r['task'],r['regime'],float(r['loss_rate']),r['channel']):r for r in policy}
    for row in actual_rows:
        assert 0 <= int(row['strict_success_original']) <= int(row['original_successes']) <= 64
        assert close(row['mean_wire_bits'], int(row['total_wire_bits'])/64)
    for row in policy:
        assert int(row['strict_successes']) <= int(row['successes']) <= 64
        assert int(row['delivered_count'])+int(row['lost_packet_count']) == int(row['admitted_count'])
        assert int(row['blocked_count'])+int(row['admitted_count']) == 64
        assert int(row['total_received_bits'])+int(row['total_lost_bits']) == int(row['total_sent_bits'])
        if row['regime']=='high' and float(row['loss_rate'])==0:
            source = actual_index[(row['model'],row['task'],row['channel']+'_generated')]
            assert int(row['successes']) == int(source['original_successes'])
    pvalues=[]
    for row in contrasts:
        n00,n01,n10,n11=(int(row[k]) for k in ['n00','n01','n10','n11'])
        assert n00+n01+n10+n11==64
        assert int(row['left_successes'])==n10+n11
        assert int(row['right_successes'])==n01+n11
        assert close(row['difference'],(n10-n01)/64)
        n=n01+n10
        p=min(1.0,2*sum(math.comb(n,k) for k in range(min(n01,n10)+1))/(2**n)) if n else 1.0
        assert close(row['mcnemar_exact_two_sided_p'],p)
        for side in ['left','right']:
            key=(row['model'],row['task'],row['regime'],0.0,row[side+'_channel'])
            assert int(row[side+'_successes'])==int(policy_index[key]['successes'])
        pvalues.append((p,row['hypothesis_id'],row))
    running=0.0
    for i,(p,_,row) in enumerate(sorted(pvalues,key=lambda item:(item[0],item[1]))):
        running=max(running,min(1.0,(len(pvalues)-i)*p))
        assert close(row['holm_adjusted_p'],running)
        assert (row['holm_reject']=='True') == (running<=0.05)
    significant=[r for r in contrasts if r['holm_reject']=='True']
    assert len(significant)==6 and all(r['regime']=='low' and float(r['difference'])<0 for r in significant)
    for row in negatives:
        source=actual_index[(row['model'],row['task'],row['condition'])]
        assert all(source[key]==value for key,value in row.items())
    qa='private_multidocument_qa_v1'; nav='private_planned_navigation_v1'
    assert [int(actual_index[('qwen',qa,c+'_generated')]['original_successes']) for c in ['text','raw','pca']]==[55,52,53]
    assert [int(actual_index[('qwen',nav,c+'_generated')]['strict_success_original']) for c in ['text','raw','pca']]==[9,16,10]
    assert int(actual_index[('llama',qa,'no_comm')]['original_successes'])==3
    assert int(actual_index[('llama',qa,'pca_mean')]['original_successes'])==2
    assert int(actual_index[('llama',nav,'pca_mean')]['original_successes'])==6
    return {'status':'verified','manifest_files_checked':len(manifest['files']),'actual_condition_rows':48,'policy_rows':72,'primary_contrasts':16,'negative_control_rows':12,'paired_world_control_rows':12,'exact_mcnemar_and_global_holm_recomputed':True,'significant_contrasts_favoring_text':6,'neural_or_raw_evidence_replayed':False}

if __name__=='__main__':
    print(json.dumps(verify(Path(__file__).resolve().parent),indent=2))
