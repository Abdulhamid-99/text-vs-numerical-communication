"""Check S2 integrity and arithmetic with Python's standard library only.

This does not reconstruct raw tensors, repeat neural inference, independently
score answers, or recreate exact confidence intervals from omitted inputs.
"""
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path, PurePosixPath
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def close(a, b):
    return math.isclose(float(a), float(b), rel_tol=1e-10, abs_tol=1e-17)


def boolean(value):
    require(value in ("True", "False"), "Invalid Boolean field")
    return value == "True"


def verify(root):
    root = Path(root)
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    expected = set(manifest["files"]) | {"manifest.json"}
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    require(actual == expected, "Package file inventory differs")
    for name, record in manifest["files"].items():
        pure = PurePosixPath(name)
        require(not pure.is_absolute() and ".." not in pure.parts and "\\" not in name,
                "Manifest path is not a safe relative path")
        raw = (root / name).read_bytes()
        require(len(raw) == record["bytes"], "Byte length mismatch: " + name)
        require(hashlib.sha256(raw).hexdigest() == record["sha256"], "SHA256 mismatch: " + name)

    def table(name):
        with (root / name).open(encoding="utf-8", newline="") as stream:
            result = list(csv.DictReader(stream))
        for row in result:
            for value in row.values():
                require(value is not None, "Malformed CSV: " + name)
                try:
                    number = float(value)
                except ValueError:
                    continue
                require(math.isfinite(number), "Nonfinite numeric value: " + name)
        return result

    sweep = table("budget_sweep.csv")
    contrasts = table("primary_contrasts.csv")
    high = table("high_budget_contrasts.csv")
    calibration = table("pca_calibration.csv")
    variance = table("pca_variance_by_rank.csv")
    costs = table("mean_cost_break_even.csv")
    fidelity = table("pca_heldout_fidelity.csv")
    family = table("pca_heldout_fidelity_by_family.csv")
    require([len(x) for x in (sweep, contrasts, high, calibration, variance, costs, fidelity, family)]
            == [180, 16, 8, 4, 32, 4, 4, 256], "Unexpected table row counts")
    models = {"qwen", "llama"}
    tasks = {"private_multidocument_qa_v1", "private_planned_navigation_v1"}
    cells = {(m, t) for m in models for t in tasks}
    key = lambda row: (row["model"], row["task"])
    for data in (calibration, costs, fidelity):
        require({key(r) for r in data} == cells, "Missing model/task cell")
    cap_grid = [0, 128, 256, 512, 1024, 2048, 4096, 8192, 16384,
                32768, 65536, 131072, 262144, 524288, 1048576]
    groups = defaultdict(list)
    for row in sweep:
        require(int(row["n_families"]) == 64, "Sweep denominator differs")
        success, strict, delivered = (int(row[x]) for x in ("successes", "strict_successes", "delivered_count"))
        require(0 <= strict <= success <= 64 and 0 <= delivered <= 64, "Invalid sweep counts")
        require(close(row["accuracy"], success / 64) and close(row["delivery_rate"], delivered / 64),
                "Sweep rate arithmetic differs")
        require(0 <= float(row["mean_sent_bits"]) <= float(row["mean_planned_wire_bits"]), "Invalid sweep costs")
        if delivered == 0:
            require(float(row["mean_sent_bits"]) == 0, "Blocked messages incur sent bits")
        if delivered == 64:
            require(close(row["mean_sent_bits"], row["mean_planned_wire_bits"]), "Full delivery costs differ")
        groups[key(row) + (row["channel"],)].append(row)
    require(set(groups) == {c + (ch,) for c in cells for ch in ("text", "raw", "pca")}, "Missing sweep series")
    for group in groups.values():
        ordered = sorted(group, key=lambda r: int(r["budget_bits"]))
        require([int(r["budget_bits"]) for r in ordered] == cap_grid, "Frozen cap grid differs")
        require([int(r["delivered_count"]) for r in ordered] == sorted(int(r["delivered_count"]) for r in ordered),
                "Admission is not monotonic")
        require(int(ordered[0]["delivered_count"]) == 0 and int(ordered[-1]["delivered_count"]) == 64,
                "Sweep endpoints differ")

    for row in contrasts:
        n00, n01, n10, n11 = (int(row[x]) for x in ("n00", "n01", "n10", "n11"))
        require(min(n00, n01, n10, n11) >= 0 and n00 + n01 + n10 + n11 == int(row["n_families"]) == 64,
                "Paired discordance counts differ")
        require(n10 + n11 == int(row["left_successes"]) and n01 + n11 == int(row["right_successes"]),
                "Paired success arithmetic differs")
        require(close(row["difference_pp"], 100 * (n10 - n01) / 64), "Difference arithmetic differs")
        require(-100 <= float(row["ci_low_pp"]) <= float(row["difference_pp"]) <= float(row["ci_high_pp"]) <= 100,
                "Confidence interval ordering differs")
        require(boolean(row["intervals_pointwise_not_familywise"]), "CI scope differs")
        n = n10 + n01
        p = min(1.0, 2 * sum(math.comb(n, k) for k in range(min(n10, n01) + 1)) / 2 ** n) if n else 1.0
        require(close(p, row["raw_p"]), "Exact McNemar arithmetic differs")
    running = 0.0
    for index, row in enumerate(sorted(contrasts, key=lambda r: float(r["raw_p"]))):
        running = max(running, min(1.0, (16 - index) * float(row["raw_p"])))
        require(close(running, row["global_holm_p"]), "Global Holm arithmetic differs")
    require(high == [r for r in contrasts if r["regime"] == "high"], "High table is not the primary-table subset")
    for row in high:
        for side in ("left", "right"):
            series = groups[key(row) + (row[side + "_channel"],)]
            unlimited = max(series, key=lambda r: int(r["budget_bits"]))
            require(row[side + "_successes"] == unlimited["successes"], "High/sweep full-admission success differs")

    calibration_index = {key(r): r for r in calibration}
    for row in calibration:
        require(int(row["calibration_families"]) == 32 and int(row["worlds_per_family"]) == 2
                and int(row["calibration_arrays"]) == 64 and int(row["rank"]) == 512, "PCA calibration dimensions differ")
        require(close(100 * float(row["explained_variance"]), row["explained_variance_percent"])
                and close(1 - float(row["explained_variance"]), row["calibration_relative_squared_reconstruction_error"]),
                "Calibration variance arithmetic differs")
    spectra = defaultdict(list)
    for row in variance:
        spectra[key(row)].append(row)
    for cell, group in spectra.items():
        ordered = sorted(group, key=lambda r: int(r["rank"]))
        require([int(r["rank"]) for r in ordered] == [1, 8, 16, 32, 64, 128, 256, 512], "Variance rank grid differs")
        values = [float(r["explained_variance_percent"]) for r in ordered]
        require(values == sorted(values) and 0 <= values[0] <= values[-1] <= 100, "Variance range differs")
        require(close(values[-1], calibration_index[cell]["explained_variance_percent"]), "Rank-512 variance differs")
    for row in costs:
        text, pca = float(row["mean_text_bits"]), float(row["mean_pca_bits"])
        require(close(pca / text, row["pca_to_text_ratio"])
                and close(100 * (1 - text / pca), row["pca_relative_reduction_to_mean_text_percent"])
                and close(100 * text / pca, row["pca_share_of_current_bits_at_mean_text_percent"]), "Mean-cost arithmetic differs")
        require(int(row["fixed_pca_framing_bits"]) == 512 > text
                and close(512 + 40 * float(row["mean_token_rows"]), row["hypothetical_rank1_mean_bits"]),
                "PCA framing arithmetic differs")
        for channel in ("text", "raw", "pca"):
            require(close(row["mean_" + channel + "_bits"], groups[key(row) + (channel,)][0]["mean_planned_wire_bits"]),
                    "Sweep/mean-cost totals differ")

    families = defaultdict(list)
    for row in family:
        require(row["metric_method"] == "numpy_float64_matmul_then_float32_all_families", "Mixed primary metric method")
        energy = float(row["squared_source_centered_about_frozen_calibration_mean"])
        require(energy > 0 and int(row["token_rows"]) > 0, "Invalid source energy or row count")
        for numerator, ratio in (("squared_error_projection", "centered_rse_projection"),
                                 ("squared_error_after_packet_quantization", "centered_rse_after_packet_quantization")):
            require(close(float(row[numerator]) / energy, row[ratio]), "Family reconstruction arithmetic differs")
        require(abs(float(row["centered_rse_after_packet_quantization"]) - float(row["independent_einsum_centered_rse_after_packet_quantization"])) < 1e-10,
                "Independent summation stability differs")
        require(float(row["independent_summation_max_abs_difference"]) < 1e-10, "Summation discrepancy exceeds recorded tolerance")
        families[key(row)].append(row)
    for row in fidelity:
        group = families[key(row)]
        require(len(group) == len({x["family_id"] for x in group}) == 64, "Family fidelity denominator differs")
        energy = sum(float(x["squared_source_centered_about_frozen_calibration_mean"]) for x in group)
        for numerator, ratio in (("squared_error_projection", "pooled_centered_rse_projection"),
                                 ("squared_error_after_packet_quantization", "pooled_centered_rse_after_packet_quantization")):
            value = sum(float(x[numerator]) for x in group) / energy
            require(close(value, row[ratio]) and close(100 * value, row[ratio + "_percent"]), "Pooled fidelity arithmetic differs")
        require(sum(int(x["token_rows"]) for x in group) == int(row["token_rows"]), "Fidelity token totals differ")
        require(sum(boolean(x["receiver_reconstruction_hash_matches"]) for x in group) == int(row["receiver_reconstruction_hash_matches"]),
                "Primary hash-match summary differs")
        require(sum(boolean(x["receiver_reconstruction_hash_matches"]) or boolean(x["alternate_summation_receiver_hash_matches"]) for x in group)
                == int(row["either_summation_receiver_hash_matches"]), "Alternate hash-match summary differs")
    require(sum(boolean(r["receiver_reconstruction_hash_matches"]) for r in family) == 255,
            "Recorded primary reconstruction-match count differs")
    require(sum(boolean(r["receiver_reconstruction_hash_matches"]) or boolean(r["alternate_summation_receiver_hash_matches"]) for r in family) == 256,
            "Recorded either-method reconstruction-match count differs")
    return {"status": "verified", "manifest_files_checked": len(manifest["files"]),
            "sweep_summary_rows": 180, "primary_contrasts": 16, "high_contrasts": 8,
            "fidelity_family_rows": 256, "recorded_primary_hash_match_count": 255,
            "recorded_either_method_hash_match_count": 256,
            "scope": "Package integrity and included-table arithmetic only",
            "raw_tensor_hashes_or_PCA_reconstruction_recomputed": False,
            "confidence_interval_endpoints_recomputed": False,
            "neural_outcomes_recomputed": False}


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent), indent=2))
