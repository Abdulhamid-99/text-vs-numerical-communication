from pathlib import Path
import hashlib,json
import numpy as np
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'SHA256.json').read_text())
for name,expected in manifest.items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
count=0
summary=json.loads((ROOT/'arguana/test_results.json').read_text())
with np.load(ROOT/'arguana/test_metrics.npz',allow_pickle=False) as arrays:
    for key in arrays.files:
        a=arrays[key]; assert a.shape==(989,3) and np.isfinite(a).all(),key
        assert key in summary,key
        np.testing.assert_allclose(a.mean(axis=0),summary[key]['metrics'],rtol=0,atol=1e-12)
        count+=1
for dataset,n in [('bright',103),('scifact',300)]:
    result=json.loads((ROOT/dataset/'results.json').read_text())
    assert result['status']=='completed' and result['execution_failures']==0
    for p in sorted((ROOT/dataset).glob('metrics_*.npy')):
        key=p.stem[len('metrics_'):]
        a=np.load(p,allow_pickle=False);assert a.shape==(n,3) and np.isfinite(a).all(),p
        means=result['summaries'][key]['mean']
        np.testing.assert_allclose(a.mean(axis=0),[means[k] for k in ['hit1','mrr10','ndcg10']],rtol=0,atol=1e-12)
        count+=1
print(json.dumps({'status':'PASS','files_hash_checked':len(manifest),'condition_metric_means_checked':count,
                  'scope':'Packaged hashes and aggregate means only; no model inference, packet decoding, ranking rescore or uncertainty replay.'},indent=2))
