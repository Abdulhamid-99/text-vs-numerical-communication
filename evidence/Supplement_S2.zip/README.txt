SUPPLEMENT S2: BUDGET SWEEP, UNCERTAINTY AND PCA FIDELITY

Text and Numerical Representations Under Shared Communication Budgets

This supplement accompanies the state-transfer experiments. It contains selected
aggregate results and a retrospective state-reconstruction diagnostic. It is
not the full research archive, a new neural experiment, or a distribution of
model weights, original activation tensors, packets or task answers. Supplement
S1 contains the principal condition, policy and control summaries.

FILES
budget_sweep.csv: 180 zero-loss model/task/channel/cap summaries over the 15
frozen caps; every row uses 64 families. Admitted and delivered counts coincide
at zero loss. The 11,520 underlying policy rows are repeated uses of saved
recipient responses, not 11,520 independent observations or new generations.
primary_contrasts.csv: 16 prespecified numeric-minus-text paired comparisons.
high_budget_contrasts.csv: the eight High comparisons, copied as a useful subset.
pca_calibration.csv: four frozen rank-512 bases, calibration sample counts and
pre-quantization retained variance. Thirty-two families per task contribute two
canonical-message worlds each; token rows are not independent observations.
pca_variance_by_rank.csv: values derived from the saved calibration singular
spectrum. These are calibration geometry only, not new receiver evaluations or
evidence selecting an optimal rank. Rank 512 was fixed before heldout creation.
mean_cost_break_even.csv: mean application-packet costs and arithmetic required
to reach mean text cost. It does not demonstrate accuracy-preserving compression.
pca_heldout_fidelity.csv: four retrospective pooled reconstruction summaries.
pca_heldout_fidelity_by_family.csv: the 256 original generated heldout spans
underlying those summaries; synthetic family identifiers contain no participants.
column_dictionary.json: definitions, units and table columns.
provenance.json: source identities, original-source hashes and analysis scope.
manifest.json: relative file inventory and SHA256 values, excluding itself.
verify_supplement.py: standard-library integrity and arithmetic checker.

VERIFYING THE DISTRIBUTED PACKAGE
Unzip into a clean directory and run with Python 3.9 or later:
    python verify_supplement.py
No third-party packages, GPU, model weights or network are required. The checker
expects the exact package inventory, so retain generated files outside that
directory. It checks file hashes, row counts, cap-grid completeness, rates and
cost arithmetic, exact McNemar p-values, the global 16-test Holm adjustment,
calibration variance arithmetic, and pooling of included per-family errors.
It does NOT reconstruct omitted raw tensors, recheck their original hashes,
rerun PCA fitting, recompute confidence-interval endpoints, score raw answers,
reproduce neural outputs, or independently verify recorded hash-match flags.
The SHA256 manifest detects file changes relative to this manifest; it is not
an authenticated signature or proof of historical experimental execution.

PRESPECIFIED AND RETROSPECTIVE WORK
The 15-cap grid, two primary cap regimes, rank-512 bases, coefficient codecs,
model/task pairings and 16 primary contrasts were frozen before heldout data.
The sweep is a descriptive deterministic replay: the original delivered
response is reused when its complete packet fits and the observed no-message
response otherwise. No encoding, rank, prompt or answer is adapted to a cap.
The listed High intervals are conservative pointwise 95% paired-discordance
intervals. Their internal union bound combines two 97.5% marginal intervals;
it does not establish simultaneous coverage across the 16 contrasts. Holm
adjusts the p-values across the 16 primary tests, not these interval endpoints.
Nonsignificant High comparisons do not establish equivalence or adequate power
for small differences.

The heldout PCA fidelity tables were computed retrospectively
from existing source arrays, frozen bases and saved coefficient packets. No
new neural generation, rank fit or task score was produced. Calibration data
use canonical messages, while these heldout arrays use observed generated
messages. Differences can therefore reflect both heldout generalization and
message-distribution differences; they do not prove a particular overfitting
mechanism. Calibration retained variance is not heldout retained information.

FIDELITY DEFINITION AND NUMERICAL REPRODUCTION
For source state matrix H, frozen calibration mean mu and fixed basis W, the
pooled relative squared error is:
    sum_f ||H_f - Hhat_f||_F^2 / sum_f ||H_f - mu||_F^2
The sum is over 64 generated-original families within one model/task cell.
This is an energy-weighted ratio, not the mean of family ratios. The projection
column uses (H-mu) W^T W + mu before coefficient quantization. The packet column
uses the independently decoded saved coefficients, float64 multiplication and
float32 reconstruction, before the subsequent receiver bfloat16 cast. State
fidelity is not semantic information retention or task-accuracy equivalence.

Local original-evidence checks verified all 256 source arrays, packets, decoded
coefficient hashes and frozen bases. The primary reconstruction method is the
same NumPy float64 matrix multiplication followed by float32 cast for all 256
families. It matches 255/256 historical reconstructed-state SHA256 values. The
remaining case, Llama QA heldout_qa_00043, matches a separate deterministic
einsum summation. The alternate method is only a cross-check and is not mixed
into the reported metric. Both methods agree within 3.11e-15 before float32;
their recorded per-family RSE values are identical at double precision. Both
hash-match indicators, the uniform method and alternate RSE are retained in
the family table. This does not claim that the primary method matches all
historical receiver buffers byte-for-byte or that the full verifier was rerun.
The portable package checker only checks arithmetic among these included
numbers: original tensors and historical receiver evidence are not included.

INTERPRETIVE BOUNDARIES
At the six tested caps 512 through 16,384 bits, all text packets fit and all
numeric packets are blocked in every model/task cell. These are tested caps,
not exact packet-size thresholds or a proof of universal text superiority.
At full admission, PCA has one additional observed navigation success for
Qwen and two for Llama, at much higher packet cost; corrected comparisons do
not establish an advantage. Success curves need not be monotone even though
admission is monotone.

The mean PCA/text ratios require reductions of about 99.14%--99.70% to match
mean text cost. This is arithmetic, not an implemented compressor. The current
PCA wrapper, tensor header and dimensions already cost 36+20+8=64 bytes, or
512 bits, before scales and coefficients. This exceeds all four mean text
costs; rank reduction alone within that format cannot reach the mean target.
The hypothetical rank-1 cost retains the existing span length, framing and
quantizer scales, and is not an evaluated receiver condition. Shared basis
setup and network framing remain outside these application-packet means.

PROVENANCE
Distributed provenance uses aliases and hashes, not personal host paths.
Original sealed records remain unchanged. Detailed local verification receipts
are identified by hash but are not bundled because they include local paths.
The supplied source bindings identify omitted evidence; they are not links to
a public archive and do not imply that this package can replay that archive.
