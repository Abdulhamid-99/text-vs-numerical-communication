Supplement S1 - Aggregate protocol and results
Text and Numerical Representations Under Shared Communication Budgets

This compact supplement contains recorded aggregate scientific results, a
selected frozen-protocol summary, source fingerprints and an executable checker.

Files
actual_conditions.csv: 48 model/task/condition summaries, including primary and
strict scores, original/alternate world scores, pointwise confidence intervals
and application-payload cost. Each row contains 64 paired families.
negative_controls.csv: the 12 no_comm/raw_zero/pca_mean rows from that table.
budget_loss_policies.csv: 72 summaries (2 models x 2 tasks x 3 channels x
2 caps x 3 loss settings), recording admitted/blocked/delivered/lost cases.
primary_contrasts.csv: all 16 prespecified numerical-minus-text comparisons,
their 2x2 paired counts, exact p-values, global Holm correction and saved intervals.
paired_world_controls.csv: 12 secondary descriptive content-following summaries.
statistics_summary.json: structured primary and secondary statistics, with
per-family identifier lists omitted. The CSV files are convenient projections.
protocol_summary.json: selected frozen design, checkpoint revisions, codecs,
Low caps and shared setup bytes. It is a summary, not the complete frozen plan.
counts.json: unchanged small count record from the completed final analysis.
recorded_verification_summary.json: status and counts from the original saved
evidence verifier; this package does not reproduce that historical verification.
column_dictionary.json: field conventions and exact CSV column names.
provenance.json: relative source identifiers, hashes and transformations.
manifest.json: byte counts and SHA256 values for every other package file.
verify_supplement.py: Python standard-library integrity/statistics checker.

Sampling and measured work
There are 64 QA and 64 navigation families, reused for both models. Alternate
worlds, channels and policy replicas are not additional independent observations.
The final study recorded 512 sender generations, 3072 recipient generations,
768 source encodings and zero source-contract failures. Policy tables add no
neural generations. The High regime is uncapped. Low is a common per-cell cap,
derived before heldout evaluation from four development raw-int4 packet costs.
Loss values 0/5/10 percent are simulated paired masks, not measured network loss.
Numerical messages encode the completed sender text; they are not original
reasoning trajectories or trained compact latent messages. Navigation uses a
public deterministic planner operating on the recipient's predicted map.

Check this package
Extract the ZIP and, from this folder, run:
    python -B verify_supplement.py
No third-party packages, network, GPU, tokenizer or model weights are needed.
The checker validates the manifest and table sizes, score/cost identities,
primary-versus-strict constraints and selected manuscript count anchors. It
recomputes all 16 exact two-sided McNemar p-values and the global Holm correction
from the included 2x2 aggregate counts. It checks that six adjusted comparisons
favor text, all under Low. It does not recompute the saved bootstrap intervals.

Scope and exclusions
The supplied aggregate counts allow those statistical checks, not independent
verification of the original neural generations. Raw private task instances,
per-family observations, source arrays, packet bytes, token IDs, PCA matrices,
model weights, tokenizer files and full production/replay code are excluded.
This is NOT a full neural rerun package or a complete saved-evidence replay
archive. Complete replay access must be arranged separately; no such public
access link is established by this supplement. Hashes identify the original source records.

Interpretation
Pointwise intervals are not simultaneous. High nonsignificance is not evidence
of equivalence. Negative-control successes and Qwen navigation's strict-format
gap remain visible. Blocked numerical packets are not charged as sent bits and
their occasional task success comes from the recorded no-message condition.
The two synthetic tasks and two same-checkpoint model pairs limit generalization.
