SUPPLEMENT S3 - RETRIEVAL EXTENSION
Text and Numerical Representations Under Shared Communication Budgets

This supplement accompanies the remote semantic retrieval experiments.
It contains frozen selection/protocol records, per-query metric arrays,
aggregate results, packet-size summaries, scientific interpretations and the
independent audit receipts for the retrieval extension. Figures/tables are
derived from those results. Supplements S1 and S2 cover the state-transfer experiments.

Run: python verify_summary.py
Requires Python 3 and NumPy. This portable checker verifies packaged SHA256
hashes and recomputes aggregate means from saved metric arrays. It does not
rerun encoder inference, decode actual packets, independently rescore document
rankings, or recompute clustered uncertainty. Those broader checks are recorded
in the included audit receipts; their complete source archives remain local.
Passing this compact checker is not equivalent to rerunning the experiment.

No benchmark full-text corpus, query text or model weights are distributed here.
The distributed JSON records use relative identifiers for the original research
workspace, experiment workspace, model cache and installed Python packages.
All original hash values inside the audit records refer to the historical
inputs at audit time. SOURCE_PROVENANCE.json gives the original SHA256
of each source record under sha256 and its distributed digest under
distributed_sha256. SHA256.json checks the files included here.
The aliases identify archived inputs; the full replay archive is held locally.

Data/model sources (licenses as declared by the source cards):
ArguAna: https://huggingface.co/datasets/BeIR/arguana - CC-BY-SA-4.0
SciFact: https://huggingface.co/datasets/BeIR/scifact - CC-BY-SA-4.0
BRIGHT: https://huggingface.co/datasets/xlangai/BRIGHT - CC-BY-4.0
BRIGHT uses original examples.query, not generated reasoning or answer fields.
Model: https://huggingface.co/BAAI/bge-small-en-v1.5 - MIT
Pinned model revision: 5c38ec7c405ec4b44b94cc5a9bb96e735b38267a

Interpretation: the modified ArguAna 64-byte primary contrast favors a raw
sign embedding. BRIGHT is inconclusive; SciFact favors text. This is not a
PCA win, a generative LLM hidden-state result, or a universal switch benefit.
The local primary comparison was fixed before held-out evaluation, within an
exploratory search for useful tasks. Message bytes exclude setup and compute.
The policy audit has a specific runtime-comparison qualification; read it.
